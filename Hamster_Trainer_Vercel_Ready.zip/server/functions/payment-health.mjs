import { getStore } from "../../lib/postgres-store.mjs";

const RECEIVER = "2J1e2Pf1n836aiH2XCsyhPWjsKmktnExu9uRpCS59VY5";
const RPC_ENDPOINT = process.env.SOLANA_RPC_URL || "https://api.mainnet.solana.com";
const STORE_NAME = "hamster-trainer-solana-payments-v1";
const json = (body, status = 200) => new Response(JSON.stringify(body, null, 2), {
  status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function addressLooksValid(value) {
  try {
    let n = 0n;
    for (const c of value) { const d = ALPHABET.indexOf(c); if (d < 0) return false; n = n * 58n + BigInt(d); }
    let bytes = n === 0n ? 0 : Math.ceil(n.toString(16).length / 2);
    let zeros = 0; while (zeros < value.length && value[zeros] === "1") zeros++;
    return zeros + bytes === 32;
  } catch { return false; }
}
export default async (request) => {
  if (request.method !== "GET") return json({ ok: false, error: "Use GET for checkout status." }, 405);
  const checks = { receiverAddressValid: addressLooksValid(RECEIVER), allowedOriginConfigured: Boolean(process.env.ALLOWED_ORIGIN), solanaRpc: false, solUsdQuote: false, postgresDatabase: false };
  try {
    const response = await fetch(RPC_ENDPOINT, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: "hamster-health", method: "getHealth", params: [] }),
      signal: AbortSignal.timeout(7000), cache: "no-store"
    });
    const data = await response.json();
    checks.solanaRpc = response.ok && data.result === "ok" && !data.error;
  } catch { checks.solanaRpc = false; }
  try {
    const response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd", {
      headers: { accept: "application/json" }, signal: AbortSignal.timeout(7000), cache: "no-store"
    });
    const data = await response.json();
    checks.solUsdQuote = response.ok && Number.isFinite(Number(data?.solana?.usd)) && Number(data.solana.usd) > 0;
  } catch { checks.solUsdQuote = false; }
  try {
    const store = getStore({ name: STORE_NAME, consistency: "strong" });
    await store.get("health-probe", { type: "json", consistency: "strong" });
    checks.postgresDatabase = true;
  } catch { checks.postgresDatabase = false; }
  const ok = Object.values(checks).every(Boolean);
  return json({
    ok, service: "Hamster Trainer SOL checkout", paymentsEnabled: true,
    network: "solana-mainnet", receiverAddress: RECEIVER,
    checks,
    note: ok ? "Checkout services passed basic health checks; this does not replace a real low-value end-to-end test." : "At least one dependency is not ready. Do not ask a buyer to pay until all checks pass."
  }, ok ? 200 : 503);
};
