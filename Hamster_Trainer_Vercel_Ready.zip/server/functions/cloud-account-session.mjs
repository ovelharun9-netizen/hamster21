import { getStore } from "../../lib/postgres-store.mjs";
import { createHash, createPublicKey, randomBytes, verify as verifyEd25519 } from "node:crypto";

const STORE = "hamster-trainer-cloud-auth-v1";
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const SESSION_TTL = 30 * 24 * 60 * 60 * 1000;
function decodeBase58(value) {
  if (typeof value !== "string" || !value.length) return Buffer.alloc(0);
  let n = 0n;
  for (const char of value) { const digit = ALPHABET.indexOf(char); if (digit < 0) throw new Error("Invalid base58 value"); n = n * 58n + BigInt(digit); }
  const hex = n.toString(16);
  const body = n === 0n ? Buffer.alloc(0) : Buffer.from(hex.padStart(hex.length + (hex.length % 2), "0"), "hex");
  let zeros = 0; while (zeros < value.length && value[zeros] === "1") zeros++;
  return Buffer.concat([Buffer.alloc(zeros), body]);
}
function getOrigin(request, body) {
  const requestOrigin = request.headers.get("origin");
  const origin = requestOrigin || body?.origin;
  if (typeof origin !== "string") return null;
  try {
    const url = new URL(origin);
    if (url.origin !== origin) return null;
    const isLocal = ["localhost", "127.0.0.1"].includes(url.hostname);
    if (url.protocol !== "https:" && !isLocal) return null;
    const allowed = process.env.ALLOWED_ORIGIN;
    if (!isLocal && !allowed) return null;
    if (allowed) {
      let allowedOrigin;
      try { allowedOrigin = new URL(allowed).origin; } catch { return null; }
      if (allowedOrigin !== url.origin) return null;
    }
    if (requestOrigin && requestOrigin !== origin) return null;
    return origin;
  } catch { return null; }
}
function headers(origin) { return { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Vary": "Origin", ...(origin ? { "Access-Control-Allow-Origin": origin } : {}), "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, Authorization" }; }
function reply(status, data, origin) { return new Response(JSON.stringify(data), { status, headers: headers(origin) }); }
function verifySignature(walletAddress, message, signatureBase64) {
  try {
    const pub = decodeBase58(walletAddress);
    const signature = Buffer.from(signatureBase64, "base64");
    if (pub.length !== 32 || signature.length !== 64) return false;
    const der = Buffer.concat([Buffer.from("302a300506032b6570032100", "hex"), pub]);
    const key = createPublicKey({ key: der, format: "der", type: "spki" });
    return verifyEd25519(null, Buffer.from(message, "utf8"), key, signature);
  } catch { return false; }
}
function tokenHash(token) { return createHash("sha256").update(token).digest("hex"); }

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers(request.headers.get("origin")) });
  if (request.method !== "POST") return reply(405, { ok: false, error: "Use POST to establish a cloud-save session." }, request.headers.get("origin"));
  let body; try { body = await request.json(); } catch { return reply(400, { ok: false, error: "Invalid JSON body." }, request.headers.get("origin")); }
  const origin = getOrigin(request, body); if (!origin) return reply(403, { ok: false, error: "This site origin is not allowed." }, null);
  const { challengeId, walletAddress, signature } = body || {};
  if (![challengeId, walletAddress, signature].every(v => typeof v === "string")) return reply(400, { ok: false, error: "Cloud-save sign-in details are incomplete." }, origin);
  const store = getStore({ name: STORE });
  let challenge;
  try { challenge = await store.get("challenge:" + challengeId, { type: "json", consistency: "strong" }); }
  catch (error) { console.error("Cloud challenge read failed", error); return reply(503, { ok: false, error: "Cloud-save authentication is temporarily unavailable." }, origin); }
  if (!challenge) return reply(404, { ok: false, error: "The sign-in challenge was not found. Connect again." }, origin);
  if (challenge.origin !== origin || challenge.walletAddress !== walletAddress) return reply(403, { ok: false, error: "The sign-in challenge does not match this site or wallet." }, origin);
  if (challenge.expiresAt < Date.now()) return reply(410, { ok: false, error: "The sign-in challenge expired. Connect again." }, origin);
  if (!verifySignature(walletAddress, challenge.message, signature)) return reply(403, { ok: false, error: "The MetaMask signature could not be verified. Cloud save was not linked." }, origin);

  try {
    const claimed = await store.setJSON("used-challenge:" + challengeId, { usedAt: Date.now() }, { onlyIfNew: true });
    if (!claimed.modified) return reply(409, { ok: false, error: "This sign-in challenge was already used. Connect again." }, origin);
    const token = randomBytes(32).toString("base64url");
    const now = Date.now(); const expiresAt = now + SESSION_TTL;
    await store.setJSON("session:" + tokenHash(token), { walletAddress, origin, createdAt: now, expiresAt }, { onlyIfNew: true });
    return reply(200, { ok: true, walletAddress, sessionToken: token, expiresAt }, origin);
  } catch (error) {
    console.error("Cloud session storage failed", error);
    return reply(503, { ok: false, error: "The cloud-save session could not be stored. Connect again." }, origin);
  }
};
