import { getStore } from "../../lib/postgres-store.mjs";
import { randomBytes, randomUUID } from "node:crypto";

const STORE = "hamster-trainer-cloud-auth-v1";
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

function decodeBase58(value) {
  if (typeof value !== "string" || !value.length) return Buffer.alloc(0);
  let n = 0n;
  for (const char of value) {
    const digit = ALPHABET.indexOf(char);
    if (digit < 0) throw new Error("Invalid base58 value");
    n = n * 58n + BigInt(digit);
  }
  const hex = n.toString(16);
  const body = n === 0n ? Buffer.alloc(0) : Buffer.from(hex.padStart(hex.length + (hex.length % 2), "0"), "hex");
  let zeros = 0;
  while (zeros < value.length && value[zeros] === "1") zeros++;
  return Buffer.concat([Buffer.alloc(zeros), body]);
}
function validAddress(value) {
  try { return decodeBase58(value).length === 32; } catch { return false; }
}
function getOrigin(request, body) {
  const requestOrigin = request.headers.get("origin");
  const origin = requestOrigin || body?.origin;
  if (typeof origin !== "string") return null;
  try {
    const url = new URL(origin);
    if (url.origin !== origin) return null;
    const isLocal = ["localhost", "127.0.0.1"].includes(url.hostname);
    if (url.protocol !== "https:" && !isLocal) return null;
    const allowed = process.env.ALLOWED_ORIGIN;
    if (!isLocal && !allowed) return null;
    if (allowed) {
      let allowedOrigin;
      try { allowedOrigin = new URL(allowed).origin; } catch { return null; }
      if (allowedOrigin !== url.origin) return null;
    }
    if (requestOrigin && requestOrigin !== origin) return null;
    return origin;
  } catch { return null; }
}
function headers(origin) {
  return { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Vary": "Origin",
    ...(origin ? { "Access-Control-Allow-Origin": origin } : {}),
    "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, Authorization" };
}
function reply(status, data, origin) { return new Response(JSON.stringify(data), { status, headers: headers(origin) }); }

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers(request.headers.get("origin")) });
  if (request.method !== "POST") return reply(405, { ok: false, error: "Use POST to start cloud-save authentication." }, request.headers.get("origin"));
  let body;
  try { body = await request.json(); } catch { return reply(400, { ok: false, error: "Invalid JSON body." }, request.headers.get("origin")); }
  const origin = getOrigin(request, body);
  if (!origin) return reply(403, { ok: false, error: "This site origin is not allowed for cloud saves." }, null);
  const walletAddress = body?.walletAddress;
  if (!validAddress(walletAddress)) return reply(400, { ok: false, error: "The connected Solana wallet address is invalid." }, origin);

  const now = Date.now();
  const challengeId = randomUUID();
  const nonce = randomBytes(24).toString("hex");
  const expiresAt = now + 5 * 60 * 1000;
  const message = [
    "Hamster Trainer Cloud Save Login v1",
    "Purpose: Sign in to sync this game's progress across devices.",
    "Origin: " + origin,
    "Wallet: " + walletAddress,
    "Nonce: " + nonce,
    "Issued At: " + new Date(now).toISOString(),
    "Expires At: " + new Date(expiresAt).toISOString(),
    "This signature does not authorize a payment or transfer."
  ].join("\n");
  try {
    const store = getStore({ name: STORE });
    await store.setJSON("challenge:" + challengeId, { challengeId, walletAddress, origin, nonce, message, createdAt: now, expiresAt }, { onlyIfNew: true });
  } catch (error) {
    console.error("Cloud auth challenge storage failed", error);
    return reply(503, { ok: false, error: "Cloud-save authentication storage is unavailable. Try again later." }, origin);
  }
  return reply(200, { ok: true, challengeId, walletAddress, message, expiresAt }, origin);
};
