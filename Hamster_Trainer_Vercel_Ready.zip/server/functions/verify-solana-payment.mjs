import { getStore } from "../../lib/postgres-store.mjs";

const STORE_NAME = "hamster-trainer-solana-payments-v1";
const MAINNET_RPC = process.env.SOLANA_RPC_URL || "https://api.mainnet.solana.com";
const RECEIVER = "2J1e2Pf1n836aiH2XCsyhPWjsKmktnExu9uRpCS59VY5";
const MEMO_PROGRAM_ID = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
const SYSTEM_PROGRAM_ID = "11111111111111111111111111111111";
const COMPUTE_BUDGET_PROGRAM_ID = "ComputeBudget111111111111111111111111111111";
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const PACKS = {
  mystery: { name: "Mystery Pack", usd: 20, count: 1 },
  chest: { name: "Hamster Chest", usd: 80, count: 5 },
  lucky: { name: "Lucky Pack", usd: 200, count: 3 },
  mega: { name: "Legendary Mega Pack", usd: 1, count: 49, contents: { legendary: 40, epic: 3, rare: 3, common: 3 } },
};

function decodeBase58(value) {
  if (typeof value !== "string" || !value.length) return Buffer.alloc(0);
  let n = 0n;
  for (const char of value) {
    const digit = ALPHABET.indexOf(char);
    if (digit < 0) throw new Error("Invalid base58 value");
    n = n * 58n + BigInt(digit);
  }
  const hex = n.toString(16);
  const body = n === 0n ? Buffer.alloc(0) : Buffer.from(hex.padStart(hex.length + (hex.length % 2), "0"), "hex");
  let zeros = 0;
  while (zeros < value.length && value[zeros] === "1") zeros++;
  return Buffer.concat([Buffer.alloc(zeros), body]);
}
function getOrigin(request, body) {
  const requestOrigin = request.headers.get("origin");
  const origin = requestOrigin || body?.origin;
  if (typeof origin !== "string") return null;
  try {
    const url = new URL(origin);
    if (url.origin !== origin) return null;
    const isLocal = ["localhost", "127.0.0.1"].includes(url.hostname);
    if (url.protocol !== "https:" && !isLocal) return null;
    const allowed = process.env.ALLOWED_ORIGIN;
    if (!isLocal && !allowed) return null;
    if (allowed) {
      let allowedOrigin;
      try { allowedOrigin = new URL(allowed).origin; } catch { return null; }
      if (allowedOrigin !== url.origin) return null;
    }
    if (requestOrigin && requestOrigin !== origin) return null;
    return origin;
  } catch { return null; }
}
function corsHeaders(origin) {
  return {
    "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Vary": "Origin",
    ...(origin ? { "Access-Control-Allow-Origin": origin } : {}),
    "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type",
  };
}
function reply(status, payload, origin) { return new Response(JSON.stringify(payload), { status, headers: corsHeaders(origin) }); }
async function rpc(method, params) {
  let response;
  try {
    response = await fetch(MAINNET_RPC, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: "hamster-trainer", method, params }),
      signal: AbortSignal.timeout(9000), cache: "no-store",
    });
  } catch { throw Object.assign(new Error("Solana RPC is temporarily unreachable."), { retryable: true }); }
  if (!response.ok) throw Object.assign(new Error("Solana RPC returned HTTP " + response.status + "."), { retryable: true });
  const json = await response.json();
  if (json.error) throw Object.assign(new Error("Solana RPC error: " + (json.error.message || "unknown error")), { retryable: true });
  return json.result;
}
function pubkeyText(accountKey) { return typeof accountKey === "string" ? accountKey : accountKey?.pubkey; }
function programText(ix, accountKeys) {
  if (typeof ix.programId === "string") return ix.programId;
  if (Number.isInteger(ix.programIdIndex)) return pubkeyText(accountKeys[ix.programIdIndex]);
  return "";
}
function memoText(ix) {
  if (typeof ix.parsed === "string") return ix.parsed;
  if (ix.parsed && typeof ix.parsed.memo === "string") return ix.parsed.memo;
  if (typeof ix.data === "string") {
    try { return decodeBase58(ix.data).toString("utf8"); } catch { return ""; }
  }
  return "";
}
function verifyTransactionShape(transaction, intent, requestedSignature) {
  const tx = transaction?.transaction;
  const meta = transaction?.meta;
  if (!tx || !tx.message || !meta) return { valid: false, error: "The transaction response was incomplete." };
  if (meta.err !== null) return { valid: false, error: "The Solana transaction failed; no pack can be delivered." };
  if (!Array.isArray(tx.signatures) || !tx.signatures.includes(requestedSignature)) return { valid: false, error: "The transaction signature does not match the requested transaction." };
  const keys = tx.message.accountKeys || [];
  const signer = keys.find(k => pubkeyText(k) === intent.walletAddress);
  if (!signer || (typeof signer === "object" && signer.signer !== true)) return { valid: false, error: "The paid transaction was not signed by the wallet connected for this order." };
  const instructions = tx.message.instructions || [];
  const transfers = [];
  const memos = [];
  const unexpected = [];
  for (const ix of instructions) {
    const programId = programText(ix, keys);
    if (programId === MEMO_PROGRAM_ID) { memos.push(ix); continue; }
    if (programId === COMPUTE_BUDGET_PROGRAM_ID) continue;
    if (programId === SYSTEM_PROGRAM_ID && ix.parsed?.type === "transfer") { transfers.push(ix.parsed.info); continue; }
    unexpected.push(programId || ix.program || "unknown program");
  }
  if (unexpected.length) return { valid: false, error: "The transaction contains an unexpected instruction and cannot be used as a pack payment." };
  if (transfers.length !== 1) return { valid: false, error: "Expected exactly one SOL transfer in the checkout transaction." };
  if (memos.length !== 1) return { valid: false, error: "The unique checkout memo is missing from this transaction." };
  const transfer = transfers[0];
  let transferLamports;
  try { transferLamports = BigInt(transfer.lamports); } catch { return { valid: false, error: "The SOL transfer amount could not be read." }; }
  if (transfer.source !== intent.walletAddress) return { valid: false, error: "The SOL sender does not match the connected wallet." };
  if (transfer.destination !== intent.receiverAddress || transfer.destination !== RECEIVER) return { valid: false, error: "The SOL recipient does not match the configured receiving wallet." };
  if (transferLamports !== BigInt(intent.lamports)) return { valid: false, error: "The SOL amount does not exactly match the server-issued checkout quote." };
  const memo = memos[0];
  if (memoText(memo) !== "HTP:" + intent.id) return { valid: false, error: "The transaction memo does not match this checkout intent." };
  const memoAccounts = Array.isArray(memo.accounts) ? memo.accounts.map(pubkeyText) : [];
  if (memoAccounts.length && !memoAccounts.includes(intent.walletAddress)) return { valid: false, error: "The checkout memo is not tied to the paying wallet." };
  const blockTimeMs = Number(transaction.blockTime) * 1000;
  if (!Number.isFinite(blockTimeMs) || blockTimeMs <= 0) return { valid: false, error: "The transaction has no valid block time." };
  if (blockTimeMs < intent.createdAt - 60_000) return { valid: false, error: "The transaction occurred before this checkout was created." };
  if (blockTimeMs > intent.expiresAt + 120_000) return { valid: false, error: "This checkout expired before the transaction was confirmed." };
  return { valid: true, blockTimeMs, slot: transaction.slot };
}

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders(request.headers.get("origin")) });
  if (request.method !== "POST") return reply(405, { verified: false, error: "Use POST to verify a payment." }, request.headers.get("origin"));
  let body;
  try { body = await request.json(); } catch { return reply(400, { verified: false, error: "Invalid JSON body." }, request.headers.get("origin")); }
  const origin = getOrigin(request, body);
  if (!origin) return reply(403, { verified: false, error: "The request origin is not allowed." }, null);
  const { intentId, packKey, walletAddress, signature } = body || {};
  if (![intentId, walletAddress, signature].every(v => typeof v === "string") || !PACKS[packKey]) return reply(400, { verified: false, error: "The payment verification request is incomplete." }, origin);
  try { if (decodeBase58(signature).length !== 64) throw new Error("bad signature"); }
  catch { return reply(400, { verified: false, error: "Invalid Solana transaction signature." }, origin); }

  const store = getStore({ name: STORE_NAME, consistency: "strong" });
  let intent;
  try { intent = await store.get("intent:" + intentId, { type: "json", consistency: "strong" }); }
  catch (error) { console.error("Intent read failed", error); return reply(503, { verified: false, retryable: true, error: "Secure payment storage is temporarily unavailable." }, origin); }
  if (!intent) return reply(404, { verified: false, error: "Checkout intent was not found. No pack was delivered." }, origin);
  if (intent.packKey !== packKey || intent.walletAddress !== walletAddress || intent.origin !== origin) return reply(403, { verified: false, error: "This payment does not match the original checkout, wallet, or site." }, origin);
  if (intent.receiverAddress !== RECEIVER) return reply(503, { verified: false, error: "Receiving-wallet configuration changed during checkout. Contact support with your transaction signature." }, origin);

  // Query the Solana RPC independently. A wallet's own success message is not trusted as proof of payment.
  let transaction;
  try {
    transaction = await rpc("getTransaction", [signature, { commitment: "finalized", encoding: "jsonParsed", maxSupportedTransactionVersion: 0 }]);
    if (!transaction) {
      const statuses = await rpc("getSignatureStatuses", [[signature], { searchTransactionHistory: true }]);
      const status = statuses?.value?.[0];
      if (status?.err) return reply(422, { verified: false, error: "Solana reports that the transaction failed. No pack was delivered." }, origin);
      return reply(202, { verified: false, pending: true, retryable: true, error: "Waiting for Solana finalization." }, origin);
    }
  } catch (error) {
    console.error("Solana RPC verification failed", error);
    return reply(503, { verified: false, pending: true, retryable: true, error: "The server could not check Solana right now. Do not pay again; retry verification." }, origin);
  }
  const shape = verifyTransactionShape(transaction, intent, signature);
  if (!shape.valid) return reply(422, { verified: false, error: shape.error, signature }, origin);

  const record = {
    signature, intentId, walletAddress, packKey, packName: intent.packName, count: intent.count, contents: intent.contents || null,
    usd: intent.usd, lamports: intent.lamports, receiverAddress: intent.receiverAddress,
    slot: shape.slot, blockTimeMs: shape.blockTimeMs, verifiedAt: Date.now(), origin,
  };
  // `onlyIfNew` is an atomic write condition; the same transaction cannot pay out for a second intent.
  const grant = {
    walletAddress, signature, intentId, packKey, packName: intent.packName, count: intent.count, contents: intent.contents || null,
    usd: intent.usd, verifiedAt: Date.now(), source: intent.packName,
  };
  async function persistRecoverableGrant() {
    // A verified purchase is kept as a wallet-owned grant so the player can recover
    // the package even if the browser closes before its local mailbox sync completes.
    await store.setJSON("wallet-grant:" + walletAddress + ":" + signature, grant, { onlyIfNew: true });
  }
  try {
    const claim = await store.setJSON("redeemed-signature:" + signature, record, { onlyIfNew: true });
    if (!claim.modified) {
      const prior = await store.get("redeemed-signature:" + signature, { type: "json", consistency: "strong" });
      if (prior && prior.intentId === intentId && prior.walletAddress === walletAddress && prior.packKey === packKey) {
        await persistRecoverableGrant();
        return reply(200, { verified: true, alreadyProcessed: true, packKey, packName: intent.packName, count: intent.count, contents: intent.contents || null, usd: intent.usd, signature, slot: prior.slot, explorerUrl: "https://explorer.solana.com/tx/" + signature }, origin);
      }
      return reply(409, { verified: false, error: "This Solana transaction has already been used for another order. No additional pack was delivered." }, origin);
    }
    const updatedIntent = { ...intent, status: "redeemed", paymentSignature: signature, redeemedAt: Date.now() };
    await store.setJSON("intent:" + intentId, updatedIntent);
    await persistRecoverableGrant();
  } catch (error) {
    console.error("Could not persist Solana redemption or recoverable grant", error);
    return reply(503, { verified: false, retryable: true, error: "The payment was confirmed on-chain, but the secure receipt or recoverable reward could not be saved. Do not pay again; retry verification or contact support with this signature." }, origin);
  }
  return reply(200, { verified: true, alreadyProcessed: false, packKey, packName: intent.packName, count: intent.count, contents: intent.contents || null, usd: intent.usd, signature, slot: shape.slot, explorerUrl: "https://explorer.solana.com/tx/" + signature }, origin);
};
