import { getStore } from "../../lib/postgres-store.mjs";
import { createHash } from "node:crypto";

const AUTH_STORE = "hamster-trainer-cloud-auth-v1";
const SAVE_STORE = "hamster-trainer-wallet-saves-v1";
const PAYMENT_STORE = "hamster-trainer-solana-payments-v1";
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function decodeBase58(value) {
  if (typeof value !== "string" || !value.length) return Buffer.alloc(0);
  let n = 0n; for (const char of value) { const digit = ALPHABET.indexOf(char); if (digit < 0) throw new Error("Invalid base58 value"); n = n * 58n + BigInt(digit); }
  const hex = n.toString(16); const body = n === 0n ? Buffer.alloc(0) : Buffer.from(hex.padStart(hex.length + (hex.length % 2), "0"), "hex");
  let zeros = 0; while (zeros < value.length && value[zeros] === "1") zeros++;
  return Buffer.concat([Buffer.alloc(zeros), body]);
}
function getOrigin(request, body) {
  const requestOrigin = request.headers.get("origin");
  const origin = requestOrigin || body?.origin;
  if (typeof origin !== "string") return null;
  try {
    const url = new URL(origin);
    if (url.origin !== origin) return null;
    const isLocal = ["localhost", "127.0.0.1"].includes(url.hostname);
    if (url.protocol !== "https:" && !isLocal) return null;
    const allowed = process.env.ALLOWED_ORIGIN;
    if (!isLocal && !allowed) return null;
    if (allowed) {
      let allowedOrigin;
      try { allowedOrigin = new URL(allowed).origin; } catch { return null; }
      if (allowedOrigin !== url.origin) return null;
    }
    if (requestOrigin && requestOrigin !== origin) return null;
    return origin;
  } catch { return null; }
}
function headers(origin) { return { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Vary": "Origin", ...(origin ? { "Access-Control-Allow-Origin": origin } : {}), "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, Authorization" }; }
function reply(status, data, origin) { return new Response(JSON.stringify(data), { status, headers: headers(origin) }); }
function tokenHash(token) { return createHash("sha256").update(token).digest("hex"); }
function validState(s) {
  if (!s || typeof s !== "object" || Array.isArray(s)) return "Save data is invalid.";
  let serialized; try { serialized = JSON.stringify(s); } catch { return "Save data could not be serialized."; }
  if (Buffer.byteLength(serialized, "utf8") > 700_000) return "The game save is too large.";
  if (!Number.isFinite(Number(s.coins)) || Number(s.coins) < 0 || Number(s.coins) > 1_000_000_000_000) return "Coin balance is outside the allowed range.";
  if (s.hamsters != null && (!Array.isArray(s.hamsters) || s.hamsters.length > 200)) return "The collection exceeds the 200-hamster limit.";
  if (s.mailbox != null && (!Array.isArray(s.mailbox) || s.mailbox.length > 1000)) return "The mailbox contains too many items.";
  if (s.purchaseHistory != null && (!Array.isArray(s.purchaseHistory) || s.purchaseHistory.length > 5000)) return "The purchase history is too large.";
  if (s.listings != null && (!Array.isArray(s.listings) || s.listings.length > 500)) return "The market list is too large.";
  if (s.food != null) {
    if (typeof s.food !== "object" || Array.isArray(s.food)) return "Food inventory is invalid.";
    for (const id of ["seed", "carrot", "peanut"]) {
      const amount = Number(s.food[id] || 0); if (!Number.isFinite(amount) || amount < 0 || amount > 1_000_000) return "Food inventory is outside the allowed range.";
    }
  }
  return null;
}
async function authenticatedSession(request, origin) {
  const header = request.headers.get("authorization") || "";
  const match = /^Bearer\s+([A-Za-z0-9_-]{40,})$/.exec(header);
  if (!match) return { error: "Cloud-save session is missing. Connect MetaMask again.", status: 401 };
  const authStore = getStore({ name: AUTH_STORE });
  const session = await authStore.get("session:" + tokenHash(match[1]), { type: "json", consistency: "strong" });
  if (!session || session.expiresAt <= Date.now()) return { error: "Cloud-save session expired. Connect MetaMask again.", status: 401 };
  if (session.origin !== origin) return { error: "This session belongs to another site origin.", status: 403 };
  try { if (decodeBase58(session.walletAddress).length !== 32) throw new Error("invalid"); }
  catch { return { error: "Cloud-save session wallet is invalid.", status: 401 }; }
  return { session };
}
async function loadVerifiedGrants(walletAddress) {
  const paymentStore = getStore({ name: PAYMENT_STORE });
  const prefix = "wallet-grant:" + walletAddress + ":";
  const { blobs = [] } = await paymentStore.list({ prefix });
  const grants = [];
  for (const item of blobs) {
    const grant = await paymentStore.get(item.key, { type: "json", consistency: "strong" });
    if (grant && grant.walletAddress === walletAddress && grant.signature && grant.packKey) grants.push(grant);
  }
  grants.sort((a, b) => Number(a.verifiedAt || 0) - Number(b.verifiedAt || 0));
  return grants.slice(-500);
}
export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers(request.headers.get("origin")) });
  if (request.method !== "POST") return reply(405, { ok: false, error: "Use POST for cloud-save operations." }, request.headers.get("origin"));
  let body; try { body = await request.json(); } catch { return reply(400, { ok: false, error: "Invalid JSON body." }, request.headers.get("origin")); }
  const origin = getOrigin(request, body); if (!origin) return reply(403, { ok: false, error: "This site origin is not allowed." }, null);
  let auth;
  try { auth = await authenticatedSession(request, origin); }
  catch (error) { console.error("Cloud session check failed", error); return reply(503, { ok: false, error: "Cloud-save storage is temporarily unavailable." }, origin); }
  if (auth.error) return reply(auth.status, { ok: false, error: auth.error }, origin);
  const { walletAddress } = auth.session;
  const saveStore = getStore({ name: SAVE_STORE });
  const saveKey = "state:" + walletAddress;
  if (body.action === "load") {
    try {
      const record = await saveStore.get(saveKey, { type: "json", consistency: "strong" });
      const grants = await loadVerifiedGrants(walletAddress);
      return reply(200, { ok: true, walletAddress, state: record?.state || null, revision: Number(record?.revision) || 0, updatedAt: Number(record?.updatedAt) || null, grants }, origin);
    } catch (error) {
      console.error("Cloud state load failed", error);
      return reply(503, { ok: false, error: "Could not load the cloud save right now. Local progress was not replaced." }, origin);
    }
  }
  if (body.action === "save") {
    const validationError = validState(body.state);
    if (validationError) return reply(400, { ok: false, error: validationError }, origin);
    try {
      // This endpoint stores a whole per-wallet game snapshot, not a currency ledger.
      // ETag compare-and-swap prevents an older tab from silently overwriting a newer snapshot.
      const current = await saveStore.getWithMetadata(saveKey, { type: "json", consistency: "strong" });
      const currentRevision = Number(current?.data?.revision) || 0;
      const expectedRevision = Number.isInteger(body.expectedRevision) && body.expectedRevision >= 0 ? body.expectedRevision : 0;
      if (expectedRevision !== currentRevision) return reply(409, { ok: false, conflict: true, error: "A newer cloud save already exists. The latest save was not overwritten.", state: current?.data?.state || null, revision: currentRevision, updatedAt: Number(current?.data?.updatedAt) || null }, origin);
      const record = { schemaVersion: 1, walletAddress, revision: currentRevision + 1, updatedAt: Date.now(), state: body.state };
      const write = current
        ? await saveStore.setJSON(saveKey, record, { onlyIfMatch: current.etag })
        : await saveStore.setJSON(saveKey, record, { onlyIfNew: true });
      if (!write.modified) {
        const latest = await saveStore.get(saveKey, { type: "json", consistency: "strong" });
        return reply(409, { ok: false, conflict: true, error: "The save changed in another session. The latest cloud copy was preserved.", state: latest?.state || null, revision: Number(latest?.revision) || 0, updatedAt: Number(latest?.updatedAt) || null }, origin);
      }
      return reply(200, { ok: true, walletAddress, revision: record.revision, updatedAt: record.updatedAt }, origin);
    } catch (error) {
      console.error("Cloud state save failed", error);
      return reply(503, { ok: false, error: "Could not save progress to the cloud. This browser still keeps its local save." }, origin);
    }
  }
  return reply(400, { ok: false, error: "Unknown cloud-save action." }, origin);
};
