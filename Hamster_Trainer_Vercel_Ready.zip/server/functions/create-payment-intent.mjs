import { getStore } from "../../lib/postgres-store.mjs";
import { randomUUID } from "node:crypto";

const STORE_NAME = "hamster-trainer-solana-payments-v1";
const MAINNET_RPC = process.env.SOLANA_RPC_URL || "https://api.mainnet.solana.com";
const RECEIVER = "2J1e2Pf1n836aiH2XCsyhPWjsKmktnExu9uRpCS59VY5";
const PACKS = {
  mystery: { name: "Mystery Pack", usd: 20, count: 1 },
  chest: { name: "Hamster Chest", usd: 80, count: 5 },
  lucky: { name: "Lucky Pack", usd: 200, count: 3 },
  mega: { name: "Legendary Mega Pack", usd: 1, count: 49, contents: { legendary: 40, epic: 3, rare: 3, common: 3 } },
};
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

function decodeBase58(value) {
  if (typeof value !== "string" || !value.length) return Buffer.alloc(0);
  let n = 0n;
  for (const char of value) {
    const digit = ALPHABET.indexOf(char);
    if (digit < 0) throw new Error("Invalid base58 value");
    n = n * 58n + BigInt(digit);
  }
  let body = n === 0n ? Buffer.alloc(0) : Buffer.from(n.toString(16).padStart(n.toString(16).length + (n.toString(16).length % 2), "0"), "hex");
  let zeros = 0;
  while (zeros < value.length && value[zeros] === "1") zeros++;
  return Buffer.concat([Buffer.alloc(zeros), body]);
}
function validAddress(value) {
  try { return decodeBase58(value).length === 32; } catch { return false; }
}
function getOrigin(request, body) {
  const requestOrigin = request.headers.get("origin");
  const origin = requestOrigin || body?.origin;
  if (typeof origin !== "string") return null;
  try {
    const url = new URL(origin);
    if (url.origin !== origin) return null;
    const isLocal = ["localhost", "127.0.0.1"].includes(url.hostname);
    if (url.protocol !== "https:" && !isLocal) return null;
    const allowed = process.env.ALLOWED_ORIGIN;
    if (!isLocal && !allowed) return null;
    if (allowed) {
      let allowedOrigin;
      try { allowedOrigin = new URL(allowed).origin; } catch { return null; }
      if (allowedOrigin !== url.origin) return null;
    }
    if (requestOrigin && requestOrigin !== origin) return null;
    return origin;
  } catch { return null; }
}
function corsHeaders(origin) {
  return {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Vary": "Origin",
    ...(origin ? { "Access-Control-Allow-Origin": origin } : {}),
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}
function reply(status, payload, origin) {
  return new Response(JSON.stringify(payload), { status, headers: corsHeaders(origin) });
}

export default async (request) => {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders(request.headers.get("origin")) });
  if (request.method !== "POST") return reply(405, { ok: false, error: "Use POST for payment intents." }, request.headers.get("origin"));
  let body;
  try { body = await request.json(); } catch { return reply(400, { ok: false, error: "Invalid JSON body." }, request.headers.get("origin")); }
  const origin = getOrigin(request, body);
  if (!origin) return reply(403, { ok: false, error: "The request origin is not allowed. Open the official Hamster Trainer website and try again." }, null);
  const pack = PACKS[body.packKey];
  if (!pack) return reply(400, { ok: false, error: "Unknown pack." }, origin);
  if (!validAddress(body.walletAddress)) return reply(400, { ok: false, error: "The connected Solana wallet address is invalid." }, origin);

  let solUsd;
  try {
    const quoteResponse = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd", { headers: { accept: "application/json" }, signal: AbortSignal.timeout(7000), cache: "no-store" });
    if (!quoteResponse.ok) throw new Error("Quote service returned " + quoteResponse.status);
    const quote = await quoteResponse.json();
    solUsd = Number(quote?.solana?.usd);
    if (!Number.isFinite(solUsd) || solUsd <= 0) throw new Error("Quote was invalid");
  } catch {
    return reply(503, { ok: false, error: "The server could not obtain a reliable SOL/USD quote. No payment was sent; please try again shortly.", retryable: true }, origin);
  }

  // The exact payable lamport amount is fixed server-side and stored with a one-time intent.
  const amountLamports = Math.ceil((pack.usd / solUsd) * 1_000_000_000);
  if (!Number.isSafeInteger(amountLamports) || amountLamports <= 0) return reply(503, { ok: false, error: "The calculated SOL amount is invalid. No payment was sent." }, origin);
  const intentId = randomUUID();
  const createdAt = Date.now();
  const intent = {
    id: intentId, packKey: body.packKey, packName: pack.name, usd: pack.usd, count: pack.count, contents: pack.contents || null,
    lamports: amountLamports, solUsd, walletAddress: body.walletAddress,
    receiverAddress: RECEIVER, origin, createdAt,
    expiresAt: createdAt + 20 * 60 * 1000, status: "pending", version: 1,
  };
  try {
    const store = getStore({ name: STORE_NAME, consistency: "strong" });
    const result = await store.setJSON("intent:" + intentId, intent, { onlyIfNew: true });
    if (!result.modified) return reply(503, { ok: false, error: "Could not reserve a unique checkout intent. No payment was sent; please try again." }, origin);
  } catch (error) {
    console.error("Unable to persist Solana payment intent", error);
    return reply(503, { ok: false, error: "Secure payment storage is unavailable. No payment was sent. Check the Vercel Function deployment and try again.", retryable: true }, origin);
  }
  return reply(200, {
    ok: true, intentId, packKey: body.packKey, packName: pack.name, usd: pack.usd, count: pack.count, contents: pack.contents || null,
    amountLamports, amountSol: amountLamports / 1_000_000_000, solUsd,
    expiresAt: intent.expiresAt, receiverAddress: RECEIVER,
  }, origin);
};
