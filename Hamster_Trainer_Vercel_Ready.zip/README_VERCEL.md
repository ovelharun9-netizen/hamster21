# Guia de implantação — Vercel

Este guia complementa o README principal. Para o caminho mais curto no Windows, execute `DEPLOY_VERCEL_WINDOWS.bat` depois de extrair o pacote e instalar o Node.js LTS.

## O que o script faz

- verifica se `node` e `npm` estão instalados;
- instala as dependências listadas no `package.json`;
- solicita autenticação na Vercel;
- vincula ou cria o projeto na Vercel;
- envia uma implantação de produção.

O script não consegue cadastrar variáveis secretas sem sua participação, não cria sua conta nem banco de dados e não confirma que o domínio está livre de alertas de segurança.

## Após a primeira implantação

Adicione `DATABASE_URL`, `ALLOWED_ORIGIN` e `SOLANA_RPC_URL` em **Vercel → Project → Settings → Environment Variables**, no ambiente Production. Salve e faça Redeploy. Depois teste `/api/payment-health` e faça os testes de login/sincronização conforme o README principal.

**Não aceite pagamentos reais enquanto persistir o aviso de segurança da MetaMask.** A migração de hospedagem não resolve esse aviso.
