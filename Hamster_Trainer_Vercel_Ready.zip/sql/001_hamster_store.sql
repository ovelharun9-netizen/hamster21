CREATE TABLE IF NOT EXISTS hamster_trainer_store (
  store_name TEXT NOT NULL,
  entry_key TEXT NOT NULL,
  value JSONB NOT NULL,
  etag TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (store_name, entry_key)
);
