# Hamster Trainer — pacote pronto para Vercel

Este pacote contém o site, o jogo, as funções de API e a configuração para implantação na Vercel. A estrutura já está organizada para a Vercel; você não precisa editar o código para fazer a primeira implantação.

## Antes de publicar

**Importante:** houve um aviso de segurança/phishing da MetaMask para o domínio anterior. Mudar de hospedagem não remove nem resolve esse aviso. Não peça aos jogadores para ignorá-lo e não aceite pagamentos reais enquanto a situação não tiver sido revisada pela MetaMask. Este pacote não é uma certificação de segurança e nenhuma compra real na Solana Mainnet foi testada.

## Opção mais simples no Windows

1. Extraia o ZIP para uma pasta normal.
2. Instale o Node.js LTS, caso ainda não esteja instalado: https://nodejs.org/
3. Abra a pasta extraída e execute `DEPLOY_VERCEL_WINDOWS.bat`.
4. Quando solicitado, entre na sua conta Vercel pelo navegador e confirme a criação/vinculação do projeto.
5. Guarde a URL que a Vercel mostrar no final.

O script instala as dependências, abre a autenticação da Vercel e inicia a implantação de produção. Ele não precisa nem deve receber senha de banco, chave privada ou frase-semente.

## Alternativa pela interface web (GitHub + Vercel)

1. Extraia o ZIP.
2. Crie um repositório no GitHub e envie **o conteúdo desta pasta** para a raiz do repositório (não envie o ZIP como um arquivo único).
3. Abra https://vercel.com/new e importe esse repositório.
4. Use a raiz do repositório como diretório do projeto. O `vercel.json` já configura os arquivos estáticos e as funções de API.

## Configuração necessária para salvamento na nuvem e pagamentos

A página pode ser publicada sem estas variáveis, mas as funções de backend que dependem delas não estarão prontas para uso completo. Depois que a Vercel atribuir a URL definitiva:

1. Crie um banco PostgreSQL na Neon: https://neon.tech/ (ou pelo marketplace da Vercel: https://vercel.com/marketplace/neon/neon).
2. No projeto da Vercel, abra **Settings → Environment Variables** e adicione estas variáveis no ambiente **Production**:

| Variável | O que preencher |
|---|---|
| `DATABASE_URL` | URL de conexão PostgreSQL *pooled* da Neon, com TLS (`sslmode=require`). Mantenha a senha privada. |
| `ALLOWED_ORIGIN` | A URL exata de produção atribuída pela Vercel, por exemplo `https://seu-projeto.vercel.app`, sem caminho e sem `/` no final. |
| `SOLANA_RPC_URL` | `https://api.mainnet.solana.com` ou um endpoint confiável de RPC da Solana Mainnet. |

3. Salve as variáveis e faça novo deploy (Deployments → menu do último deploy → Redeploy).
4. Abra `https://SUA-URL-VERCEL/api/payment-health`. Antes de considerar o backend pronto, confirme `ok: true` e que `receiverAddressValid`, `allowedOriginConfigured`, `solanaRpc`, `solUsdQuote` e `postgresDatabase` estão verdadeiros.

Não envie a senha do banco, chave privada ou frase-semente nesta conversa; cadastre segredos apenas nas variáveis de ambiente da Vercel. Não adicione um arquivo `.env` real ao GitHub.

## O que está incluído

- `public/index.html` e `public/game.html`: página inicial e jogo.
- `public/assets/`: imagens do jogo.
- `api/`: rotas das funções da Vercel.
- `server/functions/`: login por carteira, sincronização de estado, intents e validação de pagamentos.
- `lib/postgres-store.mjs`: acesso ao PostgreSQL.
- `sql/001_hamster_store.sql`: esquema do banco (há também criação automática no primeiro uso).
- `vercel.json`: configuração de implantação e rota `/game`.
- `.env.example`: exemplo sem credenciais reais.

Endereço de recebimento atualmente configurado no projeto:

`2J1e2Pf1n836aiH2XCsyhPWjsKmktnExu9uRpCS59VY5`

Confirme o destinatário e o valor na carteira antes de qualquer transação.

## Limitações importantes

A implantação não transfere automaticamente dados guardados no navegador do domínio antigo para o novo domínio. O salvamento em nuvem precisa do banco configurado e testado. Algumas mecânicas do jogo continuam do lado do cliente e não são à prova de adulteração. Um resultado positivo no endpoint de saúde é só uma verificação básica; não substitui testes completos de login, compra, verificação on-chain e entrega de recompensa na caixa de correio.
