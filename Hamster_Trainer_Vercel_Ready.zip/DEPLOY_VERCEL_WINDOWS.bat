@echo off
setlocal
cd /d "%~dp0"
title Hamster Trainer - Deploy na Vercel

echo =====================================================
echo   HAMSTER TRAINER - IMPLANTACAO NA VERCEL
echo =====================================================
echo.
echo Este script envia o projeto para a sua conta Vercel.
echo Voce precisara autenticar-se e confirmar o projeto.
echo Nenhuma senha de banco, chave privada ou frase-semente
 echo deve ser digitada neste script.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERRO: Node.js nao foi encontrado.
  echo Instale o Node.js LTS em https://nodejs.org/ e abra este script novamente.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERRO: npm nao foi encontrado. Reinstale o Node.js LTS.
  pause
  exit /b 1
)

echo [1/4] Instalando dependencias...
call npm install
if errorlevel 1 goto :failed

echo.
echo [2/4] Autenticacao na Vercel. Siga as instrucoes que aparecerem.
call npx vercel login
if errorlevel 1 goto :failed

echo.
echo [3/4] Vinculando ou criando o projeto Vercel...
call npx vercel link
if errorlevel 1 goto :failed

echo.
echo [4/4] Enviando deploy de producao...
call npx vercel deploy --prod
if errorlevel 1 goto :failed

echo.
echo Deploy enviado. Anote a URL apresentada acima.
echo Para ativar o backend, configure DATABASE_URL, ALLOWED_ORIGIN e SOLANA_RPC_URL
 echo em Project Settings - Environment Variables e faca Redeploy.
echo Teste /api/payment-health. Nao aceite pagamentos reais enquanto houver alerta
 echo de seguranca da MetaMask para o dominio.
echo.
pause
exit /b 0

:failed
echo.
echo O processo parou por causa de um erro. Leia a mensagem acima,
echo corrija o problema e execute este arquivo novamente.
pause
exit /b 1
