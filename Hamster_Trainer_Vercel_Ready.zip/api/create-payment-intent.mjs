import handler from "../server/functions/create-payment-intent.mjs";
export default { async fetch(request) { return handler(request); } };
