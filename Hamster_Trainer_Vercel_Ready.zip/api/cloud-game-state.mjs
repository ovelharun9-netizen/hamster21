import handler from "../server/functions/cloud-game-state.mjs";
export default { async fetch(request) { return handler(request); } };
