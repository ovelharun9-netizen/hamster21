import handler from "../server/functions/payment-health.mjs";
export default { async fetch(request) { return handler(request); } };
