import handler from "../server/functions/cloud-account-challenge.mjs";
export default { async fetch(request) { return handler(request); } };
