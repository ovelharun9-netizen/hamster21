import handler from "../server/functions/cloud-account-session.mjs";
export default { async fetch(request) { return handler(request); } };
