import handler from "../server/functions/verify-solana-payment.mjs";
export default { async fetch(request) { return handler(request); } };
